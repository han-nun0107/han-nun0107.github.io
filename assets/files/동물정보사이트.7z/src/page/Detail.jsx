import { useParams } from "react-router-dom";
import { data } from "../assets/data/data";

function Detail() {
  const params = useParams();
  console.log(params.id);
  const animaldata = data.find((el) => el.id === Number(params.id));
  console.log(animaldata);

  return (
    <section className="detail">
      <img src={animaldata.img} />
      <h2>{animaldata.name}</h2>
      <div>{animaldata.description}</div>
    </section>
  );
}

export default Detail;
